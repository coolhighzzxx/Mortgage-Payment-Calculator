'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FaCalculator, FaTrash, FaInfoCircle } from 'react-icons/fa'

export default function Home() {
  const [formData, setFormData] = useState({
    mortgageAmount: '',
    mortgageTerm: '',
    interestRate: '',
    mortgageType: 'repayment'
  })
  const [result, setResult] = useState(null)
  const [errors, setErrors] = useState({})

  const validateForm = () => {
    const newErrors = {}
    if (!formData.mortgageAmount) newErrors.mortgageAmount = 'Mortgage amount is required'
    if (!formData.mortgageTerm) newErrors.mortgageTerm = 'Mortgage term is required'
    if (!formData.interestRate) newErrors.interestRate = 'Interest rate is required'
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const calculateMortgage = (e) => {
    e.preventDefault()
    if (!validateForm()) return

    const P = parseFloat(formData.mortgageAmount)
    const r = parseFloat(formData.interestRate) / 100 / 12
    const n = parseFloat(formData.mortgageTerm) * 12

    let monthlyPayment
    if (formData.mortgageType === 'repayment') {
      monthlyPayment = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1)
    } else {
      monthlyPayment = P * r
    }
    const totalPayment = formData.mortgageType === 'repayment' ? monthlyPayment * n : (monthlyPayment * n) + P

    setResult({
      monthlyPayment: monthlyPayment.toFixed(2),
      totalPayment: totalPayment.toFixed(2),
      interestTotal: (totalPayment - P).toFixed(2)
    })
  }

  const clearForm = () => {
    setFormData({
      mortgageAmount: '',
      mortgageTerm: '',
      interestRate: '',
      mortgageType: 'repayment'
    })
    setResult(null)
    setErrors({})
  }

  return (
    <main className="perfect-center py-6 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-5xl"
      >
        <div className="grid md:grid-cols-2 gap-8 items-start">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="card p-6 md:p-8"
          >
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-xl font-semibold text-purple-400">Enter Details</h2>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={clearForm}
                className="text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-2 text-sm"
              >
                <FaTrash className="w-3 h-3" />
                Clear All
              </motion.button>
            </div>

            <form onSubmit={calculateMortgage} className="space-y-6">
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-medium mb-2 text-purple-300">Mortgage Amount</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-purple-400">£</span>
                    <input
                      type="number"
                      className="input-field pl-8"
                      value={formData.mortgageAmount}
                      onChange={(e) => setFormData({ ...formData, mortgageAmount: e.target.value })}
                      placeholder="Enter amount"
                    />
                  </div>
                  {errors.mortgageAmount && (
                    <motion.p 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-400 text-sm mt-2 flex items-center gap-2"
                    >
                      <FaInfoCircle className="w-3 h-3" />
                      {errors.mortgageAmount}
                    </motion.p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2 text-purple-300">Term (Years)</label>
                    <div className="relative">
                      <input
                        type="number"
                        className="input-field pr-16"
                        value={formData.mortgageTerm}
                        onChange={(e) => setFormData({ ...formData, mortgageTerm: e.target.value })}
                        placeholder="Years"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-purple-400">years</span>
                    </div>
                    {errors.mortgageTerm && (
                      <motion.p 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-red-400 text-sm mt-2 flex items-center gap-2"
                      >
                        <FaInfoCircle className="w-3 h-3" />
                        {errors.mortgageTerm}
                      </motion.p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2 text-purple-300">Interest Rate</label>
                    <div className="relative">
                      <input
                        type="number"
                        step="0.01"
                        className="input-field pr-8"
                        value={formData.interestRate}
                        onChange={(e) => setFormData({ ...formData, interestRate: e.target.value })}
                        placeholder="Rate"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-purple-400">%</span>
                    </div>
                    {errors.interestRate && (
                      <motion.p 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-red-400 text-sm mt-2 flex items-center gap-2"
                      >
                        <FaInfoCircle className="w-3 h-3" />
                        {errors.interestRate}
                      </motion.p>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-3 text-purple-300">Mortgage Type</label>
                  <div className="space-y-3">
                    <label className="radio-card">
                      <input
                        type="radio"
                        name="mortgageType"
                        value="repayment"
                        checked={formData.mortgageType === 'repayment'}
                        onChange={(e) => setFormData({ ...formData, mortgageType: e.target.value })}
                        className="sr-only"
                      />
                      <span className="ml-3 text-sm text-gray-300 transition-colors">Repayment</span>
                    </label>
                    <label className="radio-card">
                      <input
                        type="radio"
                        name="mortgageType"
                        value="interestOnly"
                        checked={formData.mortgageType === 'interestOnly'}
                        onChange={(e) => setFormData({ ...formData, mortgageType: e.target.value })}
                        className="sr-only"
                      />
                      <span className="ml-3 text-sm text-gray-300 transition-colors">Interest Only</span>
                    </label>
                  </div>
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="btn-primary w-full flex items-center justify-center gap-2"
                type="submit"
              >
                <FaCalculator className="w-4 h-4" />
                Calculate Repayments
              </motion.button>
            </form>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="card p-6 md:p-8 md:sticky md:top-8"
          >
            <AnimatePresence mode="wait">
              {!result ? (
                <motion.div
                  key="placeholder"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="text-center py-12"
                >
                  <div className="w-24 h-24 mx-auto mb-6 opacity-60">
                    <FaCalculator className="w-full h-full text-purple-500/30" />
                  </div>
                  <h2 className="text-xl font-semibold mb-3 text-purple-400">Results shown here</h2>
                  <p className="text-gray-400 text-sm max-w-sm mx-auto">
                    Complete the form and click "Calculate repayments" to see your monthly repayments
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="results"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  <div className="text-center mb-8">
                    <h2 className="text-xl font-semibold text-purple-400 mb-2">Your Mortgage Details</h2>
                    <p className="text-sm text-gray-400">Based on your inputs</p>
                  </div>

                  <div className="space-y-4">
                    <div className="result-card">
                      <p className="text-sm text-purple-300 mb-1">Monthly Payment</p>
                      <p className="text-3xl font-bold text-purple-400">£{result.monthlyPayment}</p>
                    </div>
                    <div className="result-card">
                      <p className="text-sm text-purple-300 mb-1">Total Interest</p>
                      <p className="text-3xl font-bold text-purple-500">£{result.interestTotal}</p>
                    </div>
                    <div className="result-card">
                      <p className="text-sm text-purple-300 mb-1">Total Payment</p>
                      <p className="text-3xl font-bold text-purple-600">£{result.totalPayment}</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      </motion.div>
    </main>
  )
} 